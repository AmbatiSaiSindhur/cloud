<?php

$db_name = 'mysql:host=php-database.ccjoesm05jfy.us-east-1.rds.amazonaws.com;dbname=shop_db';
$user_name = 'admin';
$user_password = '12345678';

$conn = new PDO($db_name, $user_name, $user_password);

?>